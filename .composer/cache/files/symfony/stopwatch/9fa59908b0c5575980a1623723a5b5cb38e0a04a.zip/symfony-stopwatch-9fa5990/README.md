Stopwatch Component
===================

Stopwatch provides a way to profile code.

Resources
---------

You can run the unit tests with the following command:

    $ cd path/to/Symfony/Component/Stopwatch/
    $ composer install
    $ phpunit
