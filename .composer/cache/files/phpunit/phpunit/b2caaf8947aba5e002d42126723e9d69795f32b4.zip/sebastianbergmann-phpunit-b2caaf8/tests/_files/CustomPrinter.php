<?php
class CustomPrinter extends PHPUnit_TextUI_ResultPrinter
{
}
